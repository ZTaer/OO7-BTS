

// 0.检测移动端跳转本地文件
<!-- <script type="text/javascript">
	if(window.location.toString().indexOf('pref=padindex') != -1){
	
	}
	else{
			if(/AppleWebKit.*Mobile/i.test(navigator.userAgent) || (/MIDP|SymbianOS|NOKIA|SAMSUNG|LG|NEC|TCL|Alcatel|BIRD|DBTEL|Dopod|PHILIPS|HAIER|LENOVO|MOT-|Nokia|SonyEricsson|SIE-|Amoi|ZTE/.test(navigator.userAgent))){
				if(window.location.href.indexOf("?mobile")<0)
					{
						try{
							if(/Android|Windows Phone|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent)){
								window.location.href="{ http://www.oo7.fun }/index.php"; // 设置跳转点
							}
							else if(/iPad/i.test(navigator.userAgent)){
							
							}
							else{
							
							}
						}
						catch(e){
						
						}
					}
			}
	}
</script> -->


// 1.检测到移动端跳转到其它域名
		<script type="text/javascript">
			if(window.location.toString().indexOf('pref=padindex') != -1){
			
			}
			else{
					if(/AppleWebKit.*Mobile/i.test(navigator.userAgent) || (/MIDP|SymbianOS|NOKIA|SAMSUNG|LG|NEC|TCL|Alcatel|BIRD|DBTEL|Dopod|PHILIPS|HAIER|LENOVO|MOT-|Nokia|SonyEricsson|SIE-|Amoi|ZTE/.test(navigator.userAgent))){
						if(window.location.href.indexOf("?mobile")<0)
							{
								try{
									if(/Android|Windows Phone|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent)){
										window.location.href=" http://www.oo7.fun "; //	<!-- 判断是否为手机用户,是则跳转到oo7.fun -->
									}
									else if(/iPad/i.test(navigator.userAgent)){
									
									}
									else{
									
									}
								}
								catch(e){
								
								}
							}
					}
			}
		</script> 


